# Afonso Matos da Cruz — Portfolio Website

**Grafisch Ontwerper · Gent, België**  
Live: [afonsomatosdacruz.be](https://afonsomatosdacruz.be)

---

## Inhoudsopgave

1. [Overzicht](#overzicht)
2. [Mapstructuur](#mapstructuur)
3. [Hosting & Deployment](#hosting--deployment)
4. [Onderhoud](#onderhoud)
5. [Meertalig systeem](#meertalig-systeem)
6. [Contactformulier](#contactformulier)
7. [Juridisch & GDPR](#juridisch--gdpr)
8. [Technische details](#technische-details)
9. [To-do voor publicatie](#to-do-voor-publicatie)

---

## Overzicht

Volledig statische portfolio website gebouwd in puur **HTML, CSS en JavaScript**.  
Geen frameworks. Geen build tools. Geen afhankelijkheden.

**Features:**
- Meertalig: NL / EN / FR / PT (via `js/translations.js`)
- Volledig responsive (320px tot 2560px)
- WCAG 2.2 toegankelijk
- GDPR-conform (geen tracking, geen cookies van derden, localStorage voor taalvoorkeur)
- YouTube embeds via privacy-enhanced mode (`youtube-nocookie.com`)
- Geoptimaliseerd voor SEO (structured data, OG tags, sitemap)
- Veiligheidsheaders via `_headers` (Netlify) en `.htaccess` (Apache)

---

## Mapstructuur

```
/
├── index.html              # Hoofdpagina (portfolio)
├── 404.html                # Aangepaste foutpagina
├── privacy.html            # Privacybeleid (GDPR)
├── cookies.html            # Cookiebeleid
├── disclaimer.html         # Disclaimer + credits
├── robots.txt              # Zoekmachine instructies
├── sitemap.xml             # URL structuur voor SEO
├── _headers                # Netlify/Cloudflare Pages beveiligingsheaders
├── _redirects              # Netlify redirect regels
├── .htaccess               # Apache server configuratie
│
├── project/
│   ├── smak.html           # Project: S.M.A.K. tentoonstelling
│   ├── disco.html          # Project: Disco editorial
│   └── oostende.html       # Project: Badcultuur aan Zee
│
├── assets/
│   ├── algemeen/           # Gedeelde afbeeldingen (logo, kaartje, e.a.)
│   ├── disco/              # Afbeeldingen project Disco
│   ├── fotografie/         # Foto's voor Foto & Film sectie
│   ├── misc/               # Diverse afbeeldingen
│   ├── oostende/           # Afbeeldingen project Oostende
│   ├── smak/               # Afbeeldingen project S.M.A.K.
│   ├── video/              # (Lege map voor toekomstige video)
│   └── cv-afonso-matos-da-cruz.pdf  ← VERVANG MET JOUW CV
│
├── css/
│   └── style.css           # Alle stijlen (variabelen, layout, components)
│
├── favicon/
│   ├── favicon.svg         # Vector favicon (moderne browsers)
│   └── apple-touch-icon.png # iOS homescreen icoon
│
└── js/
    ├── main.js             # Hoofdlogica (navigatie, animaties, formulier)
    ├── project.js          # Projectpagina's logica
    └── translations.js     # Alle vertalingen (NL/EN/FR/PT)
```

---

## Hosting & Deployment

### Optie 1: Netlify (aanbevolen — gratis)

1. Maak een account op [netlify.com](https://netlify.com)
2. Sleep de productiemap naar het Netlify dashboard, **of**
3. Verbind met GitHub: push naar een repository, Netlify deploys automatisch
4. Stel jouw domein in onder **Domain management**
5. De `_headers` en `_redirects` bestanden worden automatisch verwerkt ✓

### Optie 2: Cloudflare Pages (gratis)

1. Maak een account op [pages.cloudflare.com](https://pages.cloudflare.com)
2. Verbind je GitHub/GitLab repository
3. Stel build command in als: *(leeg — statische site)*
4. Output directory: `/` (root)
5. `_headers` wordt automatisch verwerkt ✓

### Optie 3: Apache/cPanel Shared Hosting

1. Upload alle bestanden via FTP/SFTP naar `public_html/`
2. `.htaccess` wordt automatisch verwerkt voor headers en 404 ✓
3. Zorg dat HTTPS actief is (gratis via Let's Encrypt in cPanel)

### Optie 4: GitHub Pages (gratis, beperkt)

1. Push naar GitHub repository
2. Activeer Pages via **Settings → Pages → Source: main branch**
3. ⚠️ `.htaccess` wordt **niet** ondersteund — gebruik Netlify voor headers
4. Stel een custom domein in indien gewenst

---

## Onderhoud

### CV bijwerken

Vervang `assets/cv-afonso-matos-da-cruz.pdf` met jouw bijgewerkte CV.  
De bestandsnaam **moet** identiek blijven, anders werken de links niet.

### Nieuw project toevoegen

1. Maak `project/nieuw-project.html` op basis van een bestaande projectpagina
2. Voeg een nieuw item toe in `js/main.js` in het `WORKS` array:
   ```js
   { title: 'Projectnaam', tags: ['Branding', 'Print'], year: 2026, slug: 'nieuw-project' }
   ```
3. Voeg de URL toe aan `sitemap.xml`
4. Voeg vertalingen toe in `js/translations.js` voor het project

### Foto's bijwerken

Voeg nieuwe foto's toe in `assets/fotografie/` en update het `PHOTOS` array in `js/main.js`:
```js
const PHOTOS = [
  { src: 'assets/fotografie/nieuwe-foto.jpg', alt: 'Beschrijving', tall: false },
  // ...
];
```

### Taal bijwerken

Alle vertalingen staan in `js/translations.js`. Elke sleutel heeft een waarde per taal:
```js
const TRANSLATIONS = {
  nl: { 'hero.title': 'Grafisch Ontwerper', /* ... */ },
  en: { 'hero.title': 'Graphic Designer',   /* ... */ },
  // fr, pt
};
```

### YouTube kortfilm bijwerken

Zoek in `index.html` naar `dQw4w9WgXcQ` en vervang met jouw YouTube video ID.  
De video ID vind je in de YouTube URL: `youtube.com/watch?v=`**VIDEO_ID**

---

## Meertalig systeem

Het systeem gebruikt een JavaScript translation object in `js/translations.js`.

**Werking:**
- Taal wordt opgeslagen in `localStorage` onder de sleutel `amc-lang`
- Standaardtaal: detectie via browsertaal, fallback naar `nl`
- Elementen met `data-i18n="sleutel"` worden vertaald bij laden en taalwissel
- `lang` attribuut op `<html>` wordt automatisch bijgewerkt

**Taal toevoegen:** Voeg een nieuw object toe aan `TRANSLATIONS` in `translations.js` en een knop in de taalwisselaar in `index.html`.

---

## Contactformulier

Het formulier is momenteel een **UI-demo** — berichten worden niet daadwerkelijk verzonden.

### Echte e-mailverzending instellen

**Aanbevolen: Formspree** (gratis tot 50 berichten/maand)

1. Maak een account op [formspree.io](https://formspree.io)
2. Maak een nieuw formulier en kopieer jouw Form ID (bijv. `xpzgkwqr`)
3. Vervang in `js/main.js` het `setTimeout` blok:

```js
// Vervang de setTimeout(...) met:
fetch('https://formspree.io/f/JOUW_FORM_ID', {
  method: 'POST',
  headers: { 'Accept': 'application/json' },
  body: new FormData(form)
})
.then(r => r.json())
.then(data => {
  if (data.ok) {
    fstatus.innerHTML = '<span class="status-ok">✓ Bericht ontvangen!</span>';
    form.reset();
  } else {
    fstatus.innerHTML = '<span class="status-error">Er ging iets mis. Probeer opnieuw.</span>';
  }
})
.catch(() => {
  fstatus.innerHTML = '<span class="status-error">Netwerkfout. Probeer opnieuw.</span>';
})
.finally(() => { if (btn) { btn.disabled = false; btn.textContent = '...'; } });
```

**Alternatieven:** Netlify Forms (gratis bij Netlify hosting), EmailJS, Web3Forms

---

## Juridisch & GDPR

| Bestand | Beschrijving |
|---------|-------------|
| `privacy.html` | AVG/GDPR privacybeleid — volledig conform |
| `cookies.html` | Cookiebeleid — geen tracking, localStorage uitgelegd |
| `disclaimer.html` | Disclaimer, IP-rechten, gebruikte fonts |

**Geen cookie banner nodig** — er zijn geen trackingcookies actief.

**Wat wél opgeslagen wordt:**
- `amc-lang` in localStorage (taalvoorkeur, geen cookie, geen tracking)

**Wat YouTube doet:**  
Embeds via `youtube-nocookie.com` — cookies pas bij afspelen video.

---

## Technische details

| Eigenschap | Waarde |
|-----------|--------|
| HTML standaard | HTML5 valide |
| CSS | Variabelen, Grid, Flexbox, clamp(), custom properties |
| JavaScript | ES6+ (geen polyfills nodig voor moderne browsers) |
| Fonts | Inter Tight, Inter, JetBrains Mono (Google Fonts) |
| Afbeeldingen | JPEG — overweeg WebP conversie voor betere performance |
| Animaties | CSS transitions + IntersectionObserver (geen GSAP/library) |
| Toegankelijkheid | WCAG 2.2 AA, skip link, focus-visible, aria labels |
| SEO | JSON-LD structured data, OG tags, Twitter Cards, sitemap |

### Performance tips

- **Afbeeldingen naar WebP converteren**: gebruik [Squoosh](https://squoosh.app) of [cwebp](https://developers.google.com/speed/webp/docs/cwebp)
- **Fonts self-hosten**: download via [google-webfonts-helper.herokuapp.com](https://google-webfonts-helper.herokuapp.com) voor betere privacy en snelheid
- **Cloudflare gratis tier**: automatische compressie, CDN en caching

---

## To-do voor publicatie

- [ ] **CV vervangen**: `assets/cv-afonso-matos-da-cruz.pdf` met jouw echte CV
- [ ] **YouTube video ID**: vervang `dQw4w9WgXcQ` in `index.html` met jouw kortfilm ID
- [ ] **Social links**: update Instagram/Behance/LinkedIn URLs in `js/main.js` en `index.html`
- [ ] **E-mailadres**: controleer `afonso.matosdecruz@student.grafischetechnieken.be` op alle pagina's
- [ ] **Domain instellen**: vervang alle `afonsomatosdacruz.be` verwijzingen met jouw domein indien anders
- [ ] **Contactformulier backend**: Formspree of Netlify Forms instellen (zie hierboven)
- [ ] **Structured data**: update sameAs URLs (Instagram, Behance, LinkedIn) in `index.html`
- [ ] **OG image**: maak een 1200×630px social preview afbeelding en update de OG image URL
- [ ] **Afbeeldingen optimaliseren**: converteer JPGs naar WebP voor betere Lighthouse score

---

*Portfolio van Afonso Matos da Cruz · Don Bosco SDW Gent · Grafische Technieken 4D A-GT*  
*Gebouwd: Juni 2026 · Laatste update: Juni 2026*
